from django.apps import AppConfig

# originally created by https://github.com/Jordanirabor/django-todo-react
# project modified by Ashley Mains
class TodoConfig(AppConfig):
    name = 'todo'
