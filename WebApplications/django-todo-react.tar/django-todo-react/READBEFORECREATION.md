Please note that only the source code and pre-configured JSON files for the REACT frontend were uploaded to the github repository. You will have to create a react-app following the instructions linked below. NOTE: It is IMPERATIVE that you install the versions indicated in the React Readme portion of the final paper. Failure to do so WILL result in compile errors for the react files.

install react:
https://scotch.io/tutorials/build-a-to-do-application-using-django-and-react#toc-setting-up-the-frontend

Ashley Mains